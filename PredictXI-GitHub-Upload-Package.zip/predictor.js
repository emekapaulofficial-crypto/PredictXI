(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const STORE = 'predictxi_v2_records';
  let lastAnalysis = null, marketFilter = 'all';
  const escapeHtml = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const today = new Date(); $('kickoff').value = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
  function makeRows(side) {
    const host = $(side + 'Matches');
    host.innerHTML = Array.from({length:5}, (_,i) => `<div class="match-row" data-side="${side}" data-index="${i}"><input type="date" aria-label="${side} match ${i+1} date"><input type="text" placeholder="Opponent" aria-label="${side} match ${i+1} opponent" maxlength="70"><select aria-label="${side} match ${i+1} venue"><option value="H">Home</option><option value="A">Away</option><option value="N">Neutral</option></select><input type="number" min="0" max="30" step="1" placeholder="GF" aria-label="Goals for"><input type="number" min="0" max="30" step="1" placeholder="GA" aria-label="Goals against"></div>`).join('');
    host.querySelectorAll('input,select').forEach(el => el.addEventListener('input', () => updateTeamSummary(side)));
  }
  makeRows('home'); makeRows('away');
  function readTeam(side) {
    const rows = [...$(side+'Matches').querySelectorAll('.match-row')];
    return rows.map((row, idx) => {
      const inputs = row.querySelectorAll('input'), venue = row.querySelector('select').value;
      const date = inputs[0].value, opponent = inputs[1].value.trim(), gfRaw = inputs[2].value, gaRaw = inputs[3].value;
      const partial = !!(date || opponent || gfRaw !== '' || gaRaw !== '');
      if (!partial) return null;
      if (!opponent || gfRaw === '' || gaRaw === '' || !Number.isInteger(Number(gfRaw)) || !Number.isInteger(Number(gaRaw)) || Number(gfRaw)<0 || Number(gaRaw)<0 || Number(gfRaw)>30 || Number(gaRaw)>30) return {invalid:true,idx};
      return {date,opponent,venue,gf:Number(gfRaw),ga:Number(gaRaw),idx};
    }).filter(Boolean);
  }
  function sortRecent(matches) { return matches.slice().sort((a,b) => (b.date||'').localeCompare(a.date||'') || a.idx-b.idx); }
  function weightedAvg(matches, key, weighting) {
    if (!matches.length) return 0;
    const sorted=sortRecent(matches), weights=sorted.map((_,i)=>weighting==='equal'?1:Math.pow(.84,i));
    return sorted.reduce((s,m,i)=>s+m[key]*weights[i],0)/weights.reduce((a,b)=>a+b,0);
  }
  function teamStats(matches, weighting) {
    const valid=sortRecent(matches), scored=weightedAvg(valid,'gf',weighting), conceded=weightedAvg(valid,'ga',weighting);
    const points=valid.reduce((s,m)=>s+(m.gf>m.ga?3:m.gf===m.ga?1:0),0);
    const weightedPoints=valid.reduce((s,m,i)=>s+(m.gf>m.ga?3:m.gf===m.ga?1:0)*(weighting==='equal'?1:Math.pow(.84,i)),0)/(weighting==='equal'?valid.length:valid.reduce((s,_,i)=>s+Math.pow(.84,i),0));
    return {matches:valid,scored,conceded,points,weightedPoints,win:valid.filter(m=>m.gf>m.ga).length,draw:valid.filter(m=>m.gf===m.ga).length,loss:valid.filter(m=>m.gf<m.ga).length,clean:valid.filter(m=>m.ga===0).length,btts:valid.filter(m=>m.gf>0&&m.ga>0).length};
  }
  function updateTeamSummary(side) {
    const raw=readTeam(side), valid=raw.filter(m=>!m.invalid), stats=teamStats(valid,$('weighting').value);
    $(side+'Count').textContent=`${valid.length}/5`;
    const target=$(side+'Summary');
    if(raw.some(m=>m.invalid)){target.innerHTML='<span style="color:var(--red)">Complete opponent and valid GF/GA for every started row.</span>';return;}
    if(!valid.length){target.textContent='Enter completed results to calculate form.';return;}
    target.innerHTML=`<strong>${stats.points}/${valid.length*3} pts</strong> · ${stats.scored.toFixed(2)} scored / match · ${stats.conceded.toFixed(2)} conceded · ${stats.win}W ${stats.draw}D ${stats.loss}L`;
  }
  function poisson(lambda,k) { let p=Math.exp(-lambda); for(let i=1;i<=k;i++) p*=lambda/i; return p; }
  function matrix(h,a,max=10) { const m=[]; for(let i=0;i<=max;i++){m[i]=[];for(let j=0;j<=max;j++)m[i][j]=poisson(h,i)*poisson(a,j);}return m; }
  function prob(m, fn) { let n=0; for(let i=0;i<m.length;i++)for(let j=0;j<m[i].length;j++)if(fn(i,j))n+=m[i][j];return n; }
  const clamp=(v,min,max)=>Math.min(max,Math.max(min,v));
  function analyse() {
    $('validation').textContent='';
    const home=$('homeName').value.trim(), away=$('awayName').value.trim();
    if(!home||!away){$('validation').textContent='Enter both home and away club names.';return;}
    if(home.toLowerCase()===away.toLowerCase()){$('validation').textContent='Home and away teams must be different.';return;}
    const rawH=readTeam('home'),rawA=readTeam('away');
    if(rawH.some(m=>m.invalid)||rawA.some(m=>m.invalid)){$('validation').textContent='Finish or clear every started match row. Each row needs an opponent and valid goals for and against.';return;}
    const hMatches=rawH, aMatches=rawA;
    if(hMatches.length<3||aMatches.length<3){$('validation').textContent='Enter at least 3 completed matches for each team. Five each is recommended; predictions with fewer than five will show lower coverage.';return;}
    const weighting=$('weighting').value, H=teamStats(hMatches,weighting), A=teamStats(aMatches,weighting);
    const L=clamp(Number($('leagueAvg').value)||1.35,.3,3.5), homeAdv=Number($('homeAdv').value)||1.08;
    // Venue-aware form adjustment: use each team's matches at the relevant venue where available, otherwise blend overall form.
    const hVenue=H.matches.filter(m=>m.venue==='H'), aVenue=A.matches.filter(m=>m.venue==='A');
    const hAttack=.68*H.scored+.32*(hVenue.length?weightedAvg(hVenue,'gf',weighting):H.scored);
    const hDef=.68*H.conceded+.32*(hVenue.length?weightedAvg(hVenue,'ga',weighting):H.conceded);
    const aAttack=.68*A.scored+.32*(aVenue.length?weightedAvg(aVenue,'gf',weighting):A.scored);
    const aDef=.68*A.conceded+.32*(aVenue.length?weightedAvg(aVenue,'ga',weighting):A.conceded);
    // Shrink small samples toward the competition baseline so a short hot streak cannot dominate the forecast.
    let xh=L*(hAttack/L)*(aDef/L)*homeAdv*.78 + L*.22;
    let xa=L*(aAttack/L)*(hDef/L)/Math.sqrt(homeAdv)*.78 + L*.22;
    const formH=H.weightedPoints, formA=A.weightedPoints;
    xh*=1+clamp((formH-1.35)*.035,-.12,.12); xa*=1+clamp((formA-1.35)*.035,-.12,.12);
    const absence=$('absences').value;
    if(absence==='home'||absence==='both'){xh*=.92;xa*=1.03;} if(absence==='away'||absence==='both'){xa*=.92;xh*=1.03;}
    xh=clamp(xh,.15,4.5);xa=clamp(xa,.15,4.5);
    const m=matrix(xh,xa), total=xh+xa;
    const hw=prob(m,(i,j)=>i>j), dr=prob(m,(i,j)=>i===j), aw=prob(m,(i,j)=>i<j);
    const over=n=>prob(m,(i,j)=>i+j>n), homeOver=n=>prob(m,i=>i>n), awayOver=n=>prob(m,(i,j)=>j>n);
    const btts=prob(m,(i,j)=>i>0&&j>0), noBtts=1-btts;
    // First-half goal markets: approximate 44% of expected goals in the first half.
    // This is a league-level assumption, not a live or league-verified statistic.
    const firstHalfTotal=total*.44;
    const firstHalfOver=n=>{let c=0;for(let i=0;i<=10;i++)if(i>n)c+=poisson(firstHalfTotal,i);return clamp(c,0,1)};
    const scores=[];for(let i=0;i<8;i++)for(let j=0;j<8;j++)scores.push({score:`${i}-${j}`,p:m[i][j]});scores.sort((a,b)=>b.p-a.p);
    const coverage=Math.round(((H.matches.length+A.matches.length)/10)*100);
    const markets=[
      {name:`${home} or Draw (1X)`,p:hw+dr,group:'safer',type:'Double chance'},
      {name:`${away} or Draw (X2)`,p:aw+dr,group:'safer',type:'Double chance'},
      {name:'1st Half Over 0.5 goals',p:firstHalfOver(0),group:'firsthalf',type:'1st-half total goals'},
      {name:'1st Half Under 0.5 goals',p:1-firstHalfOver(0),group:'firsthalf',type:'1st-half total goals'},
      {name:'1st Half Over 1.5 goals',p:firstHalfOver(1),group:'firsthalf',type:'1st-half total goals'},
      {name:'1st Half Under 1.5 goals',p:1-firstHalfOver(1),group:'firsthalf',type:'1st-half total goals'},
      {name:'1st Half Over 2.5 goals',p:firstHalfOver(2),group:'firsthalf',type:'1st-half total goals'},
      {name:'1st Half Under 2.5 goals',p:1-firstHalfOver(2),group:'firsthalf',type:'1st-half total goals'},
      {name:'1st Half Over 3.5 goals',p:firstHalfOver(3),group:'firsthalf',type:'1st-half total goals'},
      {name:'1st Half Under 3.5 goals',p:1-firstHalfOver(3),group:'firsthalf',type:'1st-half total goals'},
      {name:'Over 0.5 total goals',p:over(0),group:'goals',type:'Total goals'},
      {name:'Under 4.5 total goals',p:1-over(4),group:'safer',type:'Total goals'},
      {name:'Over 1.5 total goals',p:over(1),group:'goals',type:'Total goals'},
      {name:'Under 3.5 total goals',p:1-over(3),group:'goals',type:'Total goals'},
      {name:'Over 2.5 total goals',p:over(2),group:'goals',type:'Total goals'},
      {name:'Under 2.5 total goals',p:1-over(2),group:'goals',type:'Total goals'},
      {name:'Both teams to score — Yes',p:btts,group:'goals',type:'BTTS'},
      {name:'Both teams to score — No',p:noBtts,group:'goals',type:'BTTS'},
      {name:`${home} to score 1+`,p:homeOver(0),group:'goals',type:'Team goals'},
      {name:`${home} to score 2+`,p:homeOver(1),group:'goals',type:'Team goals'},
      {name:`${away} to score 1+`,p:awayOver(0),group:'goals',type:'Team goals'},
      {name:`${away} to score 2+`,p:awayOver(1),group:'goals',type:'Team goals'},
      {name:`${home} win`,p:hw,group:'result',type:'1X2'},
      {name:'Draw',p:dr,group:'result',type:'1X2'},
      {name:`${away} win`,p:aw,group:'result',type:'1X2'},
      {name:`${home} Draw No Bet`,p:hw/(hw+aw||1),group:'result',type:'Draw no bet'},
      {name:`${away} Draw No Bet`,p:aw/(hw+aw||1),group:'result',type:'Draw no bet'}
    ].map(x=>({...x,p:clamp(x.p,0.0001,.9999)}));
    lastAnalysis={home,away,league:$('league').value.trim(),kickoff:$('kickoff').value,H,A,xh,xa,hw,dr,aw,scores,markets,coverage,created:new Date().toISOString()};
    $('resultTitle').textContent=`${home} vs ${away}`;
    $('resultSub').textContent=`${$('league').value.trim()||'Competition not specified'} · ${$('kickoff').value||'Kick-off date not specified'} · based on ${H.matches.length} + ${A.matches.length} entered results`;
    $('homeProbLabel').textContent=home;$('awayProbLabel').textContent=away;
    $('homeProb').textContent=fmtPct(hw);$('drawProb').textContent=fmtPct(dr);$('awayProb').textContent=fmtPct(aw);
    $('homeBar').style.width=(hw*100)+'%';$('drawBar').style.width=(dr*100)+'%';$('awayBar').style.width=(aw*100)+'%';
    $('xg').textContent=`${xh.toFixed(2)} — ${xa.toFixed(2)}`;$('topScore').textContent=scores[0].score;$('coverage').textContent=`${coverage}% (${H.matches.length+A.matches.length}/10)`;
    $('modelExplain').textContent=`Expected goals combine recency-weighted scoring and conceding averages, venue context and a competition baseline. Recent form points are ${formH.toFixed(1)} for ${home} and ${formA.toFixed(1)} for ${away}. The model does not know confirmed line-ups, live injuries or unentered results. These are estimates, not guarantees.`;
    renderFormCompare(home,away,H,A);renderMarkets();$('results').classList.remove('hidden');$('results').scrollIntoView({behavior:'smooth',block:'start'});
  }
  function fmtPct(p){return `${(p*100).toFixed(1)}%`;}
  function renderFormCompare(home,away,H,A){
    const block=(name,S)=>{const ms=sortRecent(S.matches);return `<div><div class="form-team-head"><b>${escapeHtml(name)}</b><span>${S.points}/${ms.length*3} pts</span></div><div class="form-badges">${ms.map(m=>`<span class="form-badge ${m.gf>m.ga?'W':m.gf===m.ga?'D':'L'}" title="${escapeHtml(m.opponent)} ${m.gf}-${m.ga}">${m.gf>m.ga?'W':m.gf===m.ga?'D':'L'}</span>`).join('')}</div><div class="micro-note">${S.win} wins · ${S.draw} draws · ${S.loss} losses · goals ${S.scored.toFixed(1)} for / ${S.conceded.toFixed(1)} against per game</div></div>`;};
    $('formCompare').innerHTML=block(home,H)+block(away,A);
  }
  function renderMarkets(){
    if(!lastAnalysis)return;const list=$('marketList'), savedOdds={};
    list.querySelectorAll('.odds-input').forEach(i=>{savedOdds[i.dataset.name]=i.value;});
    let arr=lastAnalysis.markets.map((m,i)=>({...m,index:i}));
    if(marketFilter==='safer')arr=arr.filter(m=>m.p>=.70).sort((a,b)=>b.p-a.p);
    else if(marketFilter!=='all')arr=arr.filter(m=>m.group===marketFilter);
    list.innerHTML=arr.map(m=>`<div class="market-row"><div><div class="market-name">${escapeHtml(m.name)}</div><div class="market-tag">${m.type} · ${m.p>=.8?'Higher model probability':m.p>=.65?'Moderate model probability':'Lower model probability'}</div></div><div class="market-chance">${fmtPct(m.p)}</div><div class="market-fair"><small>FAIR ODDS</small><b>${(1/m.p).toFixed(2)}</b></div><div class="market-value"><small>BOOK ODDS</small><input class="odds-input" data-index="${m.index}" data-name="${escapeHtml(m.name)}" type="number" min="1.01" max="1000" step="0.01" placeholder="e.g. 1.45" value="${escapeHtml(savedOdds[m.name]||'')}"><span class="value-result value-no">Enter odds</span></div></div>`).join('')||'<div class="empty-row">No markets match this filter.</div>';
    list.querySelectorAll('.odds-input').forEach(inp=>{inp.addEventListener('input',()=>updateOdds(inp));});
  }
  function updateOdds(inp){const out=inp.parentElement.querySelector('.value-result'),o=Number(inp.value),m=lastAnalysis?.markets[Number(inp.dataset.index)];if(!m||!inp.value||!Number.isFinite(o)||o<=1){out.className='value-result value-no';out.textContent='Enter odds';return;}const implied=1/o,ev=m.p*o-1,edge=m.p-implied;out.className='value-result '+(ev>0.03?'value-good':'value-no');out.textContent=`${ev>0.03?'Potential value':'No clear value'} · ${ev>=0?'+':''}${(ev*100).toFixed(1)}% EV`;out.title=`Implied probability ${(implied*100).toFixed(1)}%; model edge ${(edge*100).toFixed(1)} percentage points.`;}
  function loadRecords(){try{const r=JSON.parse(localStorage.getItem(STORE)||'[]');return Array.isArray(r)?r:[];}catch{return[];}}
  function saveRecords(r){try{localStorage.setItem(STORE,JSON.stringify(r));}catch{alert('Browser storage is unavailable. Export your record before closing this page.');}}
  function renderRecords(){const records=loadRecords(),settled=records.filter(r=>r.result==='W'||r.result==='L'),wins=settled.filter(r=>r.result==='W').length;$('savedCount').textContent=records.length;$('settledCount').textContent=settled.length;$('hitRate').textContent=settled.length?`${Math.round(wins/settled.length*100)}%`:'—';
    $('recordRows').innerHTML=records.length?records.map((r,i)=>`<tr><td>${escapeHtml(r.date||'—')}</td><td>${escapeHtml(r.fixture||'—')}</td><td>${escapeHtml(r.selection||'—')}</td><td>${Number(r.probability).toFixed(1)}%</td><td>${r.odds?Number(r.odds).toFixed(2):'—'}</td><td><select data-record="${i}" aria-label="Set result"><option value="P" ${(!r.result||r.result==='P')?'selected':''}>Pending</option><option value="W" ${r.result==='W'?'selected':''}>Won</option><option value="L" ${r.result==='L'?'selected':''}>Lost</option></select></td><td><button class="btn btn-quiet" data-remove="${i}" type="button">Remove</button></td></tr>`).join(''):'<tr><td colspan="7" class="empty-row">No saved picks yet. Save a market above to begin.</td></tr>';
    $('recordRows').querySelectorAll('select[data-record]').forEach(s=>s.addEventListener('change',()=>{const r=loadRecords();if(r[s.dataset.record])r[s.dataset.record].result=s.value;saveRecords(r);renderRecords();}));$('recordRows').querySelectorAll('button[data-remove]').forEach(b=>b.addEventListener('click',()=>{const r=loadRecords();r.splice(Number(b.dataset.remove),1);saveRecords(r);renderRecords();}));
  }
  $('saveAnalysisBtn').addEventListener('click',()=>{
    if(!lastAnalysis){$('validation').textContent='Analyse a match first.';return;}
    const rows=[...$('marketList').querySelectorAll('.market-row')];let count=0;const records=loadRecords();
    rows.forEach(row=>{const inp=row.querySelector('.odds-input');if(!inp)return;const idx=Number(inp.dataset.index),m=lastAnalysis.markets[idx];if(!m)return;const rec={id:Date.now()+'-'+Math.random().toString(36).slice(2,7),date:new Date().toISOString().slice(0,10),fixture:`${lastAnalysis.home} vs ${lastAnalysis.away}`,selection:m.name,probability:m.p*100,odds:Number(inp.value)>1?Number(inp.value):null,result:'P',league:lastAnalysis.league};if(!records.some(x=>x.fixture===rec.fixture&&x.selection===rec.selection&&x.date===rec.date)) {records.unshift(rec);count++;}});
    saveRecords(records);renderRecords();alert(count?`Saved ${count} visible market selections to your local track record.`:'No new selections saved. You may have already saved these markets.');
  });
  // Download/import portable form data so users can prepare a fixture in Excel or offline.
  const FORM_COLUMNS=['league','kickoff','leagueAvg','homeName','awayName','homeAdv','absences','weighting','side','match_date','opponent','venue','goals_for','goals_against'];
  const csvCell=v=>`"${String(v??'').replace(/"/g,'""')}"`;
  function currentFormData(){
    const base={league:$('league').value,kickoff:$('kickoff').value,leagueAvg:$('leagueAvg').value,homeName:$('homeName').value,awayName:$('awayName').value,homeAdv:$('homeAdv').value,absences:$('absences').value,weighting:$('weighting').value};
    const rows=[];
    for(const side of ['home','away']){
      const host=$(side+'Matches');
      [...host.querySelectorAll('.match-row')].forEach(row=>{
        const inputs=row.querySelectorAll('input');
        rows.push({...base,side,match_date:inputs[0].value,opponent:inputs[1].value,venue:row.querySelector('select').value,goals_for:inputs[2].value,goals_against:inputs[3].value});
      });
    }
    return rows;
  }
  function downloadBlob(content,type,filename){
    const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  $('downloadTemplateBtn').addEventListener('click',()=>{
    const rows=[];
    for(const side of ['home','away'])for(let i=0;i<5;i++)rows.push({league:'',kickoff:$('kickoff').value,leagueAvg:'1.35',homeName:'',awayName:'',homeAdv:'1.08',absences:'none',weighting:'recent',side,match_date:'',opponent:'',venue:side==='home'?'H':'A',goals_for:'',goals_against:''});
    downloadBlob([FORM_COLUMNS.join(','),...rows.map(r=>FORM_COLUMNS.map(k=>csvCell(r[k])).join(','))].join('\r\n'),'text/csv;charset=utf-8;','predictxi-form-template.csv');
  });
  $('exportFormBtn').addEventListener('click',()=>downloadBlob(JSON.stringify({format:'PredictXI form v1',exportedAt:new Date().toISOString(),rows:currentFormData()},null,2),'application/json;charset=utf-8;','predictxi-current-form.json'));
  function parseCsv(text){
    const out=[];let row=[],cell='',quoted=false;
    for(let i=0;i<text.length;i++){const c=text[i];if(quoted){if(c==='"'&&text[i+1]==='"'){cell+='"';i++;}else if(c==='"')quoted=false;else cell+=c;}else if(c==='"')quoted=true;else if(c===','){row.push(cell);cell='';}else if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(v=>v!==''))out.push(row);row=[];cell='';}else cell+=c;}
    if(cell!==''||row.length){row.push(cell);if(row.some(v=>v!==''))out.push(row);}if(!out.length)return[];
    const headers=out.shift().map(h=>h.trim().replace(/^\uFEFF/,''));return out.map(cells=>Object.fromEntries(headers.map((h,i)=>[h,(cells[i]??'').trim()])));
  }
  function applyFormRows(rows){
    if(!Array.isArray(rows)||!rows.length)throw new Error('The file contains no form rows.');
    const first=rows[0];for(const key of ['league','kickoff','leagueAvg','homeName','awayName','homeAdv','absences','weighting'])if(first[key]!==undefined&&$(key))$(key).value=first[key];
    let count=0;
    for(const side of ['home','away']){
      const data=rows.filter(r=>String(r.side||'').toLowerCase()===side).slice(0,5),host=$(side+'Matches'),matchRows=[...host.querySelectorAll('.match-row')];
      matchRows.forEach((row,i)=>{const r=data[i]||{},inputs=row.querySelectorAll('input');inputs[0].value=r.match_date||r.date||'';inputs[1].value=r.opponent||'';row.querySelector('select').value=['H','A','N'].includes(r.venue)?r.venue:(side==='home'?'H':'A');inputs[2].value=r.goals_for??r.gf??'';inputs[3].value=r.goals_against??r.ga??'';if(r.opponent||r.goals_for!==undefined||r.gf!==undefined)count++;});updateTeamSummary(side);
    }
    $('results').classList.add('hidden');lastAnalysis=null;$('validation').textContent=`Imported form successfully. ${count} recent-match rows populated. Review the details, then select Analyse match.`;
  }
  $('importFormFile').addEventListener('change',async e=>{
    const file=e.target.files?.[0];if(!file)return;
    try{const content=await file.text();let rows;if(file.name.toLowerCase().endsWith('.json')){const obj=JSON.parse(content);rows=Array.isArray(obj)?obj:obj.rows;}else rows=parseCsv(content);applyFormRows(rows);}
    catch(err){alert(`Could not import this file: ${err.message||'Check that it is a PredictXI CSV or JSON form.'}`);}finally{e.target.value='';}
  });
  $('predictBtn').addEventListener('click',analyse);
  $('weighting').addEventListener('change',()=>{updateTeamSummary('home');updateTeamSummary('away');});
  $('marketTabs').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{marketFilter=b.dataset.filter;$('marketTabs').querySelectorAll('button').forEach(x=>x.classList.toggle('active',x===b));renderMarkets();}));
  $('clearBtn').addEventListener('click',()=>{if(confirm('Clear every saved pick from this browser? This cannot be undone.')){saveRecords([]);renderRecords();}});
  $('exportBtn').addEventListener('click',()=>{const rows=loadRecords();if(!rows.length){alert('There are no saved picks to export yet.');return;}const keys=['date','fixture','league','selection','probability','odds','result'];const quote=v=>`"${String(v??'').replace(/"/g,'""')}"`;const csv=[keys.join(','),...rows.map(r=>keys.map(k=>quote(r[k])).join(','))].join('\r\n');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}));const a=document.createElement('a');a.href=url;a.download='predictxi-track-record.csv';a.click();URL.revokeObjectURL(url);});
  $('demoBtn').addEventListener('click',()=>{
    $('league').value='Example League';$('homeName').value='Northbridge FC';$('awayName').value='Riverside United';$('leagueAvg').value='1.35';
    const exampleH=[['2026-10-10','Eastvale', 'H',2,0],['2026-10-04','Kingsport','A',1,1],['2026-09-28','Westmoor','H',3,1],['2026-09-21','Harbour FC','A',0,1],['2026-09-14','Oldcastle','H',2,1]];
    const exampleA=[['2026-10-11','Southgate','A',0,2],['2026-10-05','Lakeside','H',2,2],['2026-09-29','Kingsport','A',1,3],['2026-09-22','Eastvale','H',1,0],['2026-09-15','Westmoor','A',1,1]];
    [['home',exampleH],['away',exampleA]].forEach(([side,data])=>{const rows=[...$(side+'Matches').querySelectorAll('.match-row')];rows.forEach((r,i)=>{const inputs=r.querySelectorAll('input');inputs[0].value=data[i][0];inputs[1].value=data[i][1];r.querySelector('select').value=data[i][2];inputs[2].value=data[i][3];inputs[3].value=data[i][4];});updateTeamSummary(side);});
    $('validation').textContent='Example values loaded for demonstration only — not real club results.';
  });
  $('bookSource').addEventListener('change',()=>{const source=$('bookSource').value;if(source==='SportsBet.com')window.open('https://www.sportsbet.com/sports/soccer.html','_blank','noopener');else if(source==='SportyBet')window.open('https://www.sportybet.com/ng/','_blank','noopener');});
  renderRecords();
})();
