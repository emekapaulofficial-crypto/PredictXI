# PredictXI Football Match Lab

Mobile-first football match analysis app. The active `index.html` uses the manually supplied match history entered by the user and calculates probability estimates from the latest 3–5 results for each team.

## Features
- Manual home and away club entry, competition, kick-off date and league scoring baseline.
- Five match rows per team with date, opponent, venue, goals for and goals against.
- Recency-weighted form, venue-aware attack/defence averages, modest shrinkage toward league average, and a Poisson score-probability model.
- Home/draw/away probabilities, expected goals, most likely score, form summaries and data-coverage indicator.
- Double chance, totals, both-teams-to-score and team-goal markets.
- Optional bookmaker decimal-odds entry, implied probability, fair odds and a simple expected-value comparison.
- Local browser pick history, won/lost/pending settlement and CSV export.
- Responsive desktop and mobile layouts.

## Run locally
Open `index.html` in a browser or serve this folder with any static web server. No build step or API key is required for manual analysis.

## Data and odds limitations
- No live results feed or live bookmaker odds API is connected. Results and odds must be entered/checked manually; selecting SportsBet.com or SportyBet opens that provider's public soccer/football page in a new tab.
- The example-data button uses fictional demonstration clubs and scores. It is not real-world data.
- The model is a small-sample statistical estimate, not a guarantee or a verified winning strategy. Its displayed probabilities have not been validated by a historical backtest for this deployment.
- Pick history is stored only in this browser's local storage. It does not sync across devices.
- The older StatKick backend files in this repository are retained for reference but are not loaded by the new `index.html`. Wallet, pools, authentication, payment, and settlement functionality are not part of this manual predictor interface.

## Responsible use
For informational purposes only. Predictions can be wrong. No outcome is guaranteed. Use only where legally permitted and never stake money you cannot afford to lose.
